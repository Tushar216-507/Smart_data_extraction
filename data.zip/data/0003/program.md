## Beschreibung des Studienfachs

Der Masterstudiengang Albanologie bietet ein umfangreiches interdisziplinäres Studienprofil an, in dem Studierende die Möglichkeit haben, fundierte Kenntnisse mit direkter Forschungsanbindung über die sprachlichen, historischen und kulturellen Besonderheiten zu erlangen, durch die sich der albanischsprachige Raum auf dem Westbalkan sowie die historische albanischsprachige Diaspora in Europa auszeichnet. Die Basis bilden vertiefte Kenntnisse im Albanischen in dessen vielfältigen, landschaftlich bezogenen Varietäten sowie in den älteren Stufen der albanischen Schriftkultur (XV. – XIX. Jh.). Parallel dazu wird großes Gewicht auf die sprachpraktische Ausbildung im Standard-Albanischen mit Kompetenzen in Textverständnis und -produktion und Grammatik gelegt. Die Studienziele und das Qualifikationsprofil des Studiengangs beinhalten im Einzelnen folgende Kenntnisse und Fähigkeiten:

- Abschließende sprachpraktische Ausbildung auf Kompetenzniveau C1/C2 nach dem Gemeinsamen Europäischen Referenzrahmen (GER) im Standard-Albanischen in den Bereichen Landeskunde, Übersetzung, Textproduktion und Grammatik. Je nach Modulwahl können in geringerem Umfang auch Kenntnisse in einer Nachbarsprache (Neugriechisch, Italienisch, Serbisch-Kroatisch, Rumänisch, Bulgarisch, Mazedonisch, Türkisch) erworben werden.

- Fähigkeit zur linguistischen und kulturbezogenen Analyse literarischer Texte und anderer Sprachdenkmäler aus verschiedenen Epochen;

- Fähigkeit zur Verbindung der albanologischen Sprach- und Kulturforschung mit Erkenntnissen und Theorien der Arealtypologie, der allgemeinen Sprachwissenschaft und der Ethnolinguistik; Einblick in die Prinzipien und Faktoren des Sprach- und Kulturwandels, des Zusammenhangs zwischen der Sprach- und Kulturgeschichte und der Gegenwart sowie in die Zusammenhänge zwischen inner- und außersprachlichem Wandel (indoeuropäische und balkanbezogene Sprach- und Kulturgeschichte);

- Fähigkeit zur Sprachanalyse aus sprachvergleichender und arealtypologischer Perspektive, Rekonstruktion prähistorischer Sprachstufen; Einblick in die wissenschaftliche Auseinandersetzung mit dem Problemkreis „Albanische Frage“ aus verschiedenen Wissensbereichen wie albanische Geschichte, Religion und Anthropologie.

Über diese Aspekte hinaus vernetzt der MA Albanologie eine Vielzahl scheinbar divergierender Disziplinen wie Sprach- und Literaturwissenschaft, Südosteuropa-Linguistik und -Geschichte, Eurolinguistik, Kultur- und Religionswissenschaft sowie aktuelle Landeskunde. Für Studierende bieten sich daher die besten Voraussetzungen, den Westbalkan und Adriaraum zu studieren. Besonderen Interessen oder Wünschen zum Studium wird durch ein breites Lehrangebot Rechnung getragen, aus dem Studierende neben den Pflichtveranstaltungen diejenigen Wahlveranstaltungen wählen , die für ihre beruflichen und akademischen Zielsetzungen von Relevanz sind. Der hier dargestellte modulare Studienaufbau soll Studierenden daher lediglich als Orientierungshilfe dienen.

Der Masterstudiengang Albanologie ist interdisziplinär angelegt, sprachwissenschaftlich orientierte Lehrveranstaltungen machen aber eine wesentliche Komponente des Lehrangebots aus. Studierende sollten daher grundsätzlich die Bereitschaft und das Interesse mitbringen, sich mit wesentlichen Aspekten der Albanologie als komplexer Regionalwissenschaft auseinanderzusetzen.

### Tätigkeits- und Berufsfelder

Die Auslegung des Studienfachs mit Schwerpunkt auf Albanologie, in der Studierende neben dem hochqualifizierten Spracherwerb alle wesentlichen empirischen und Theorie bezogenen Grundlagen für selbstständige linguistische Forschungen vermittelt bekommen, soll in erster Linie als eine Chance gesehen werden, eine weiterführende akademische Berufskarriere fortzuführen. Vorrangig ist in diesem Zusammenhang die Berufstätigkeit als Hochschuldozent, Lehrbeauftragter oder an einem Forschungsinstitut vorgesehen. Zu diesem Zweck sollte bereits zu Beginn des Studiums nach Möglichkeiten Ausschau gehalten werden, erste akademische Erfahrungen zu sammeln. In erster Linie bieten sich dabei Praktika oder die Teilnahme an Konferenzen und Seminaren während der Studienzeit an. Studierende können dabei auf ein breites Angebot an unterschiedlichen Programmen zwischen der LMU bzw. den am Gemeinsamen Geistes- und Sozialwissenschaftlichen Profilbereich beteiligten Fächern und ausländischen Bildungsinstitutionen zurückgreifen (näheres dazu auf den jeweiligen [LMU-Seiten der Fächer](https://www.albanologie.uni-muenchen.de/studieng__nge/ma-albanologie/index.html#Links)).

Ungeachtet dessen sind Studierende hinsichtlich ihrer Berufsmöglichkeiten keineswegs auf eine Karriere im akademischen Bereich eingeschränkt, zumal der Masterstudiengang Albanologie neben der Vermittlung vom grundlegenden landeskundlichen Wissen über Kultur, Geschichte und Religion im albanischsprachigem Raum und darüber hinaus im Balkan auch die gegenwärtigen Entwicklungen in Albanien, Kosovo, Italien und Südosteuropa im Blick hat. Vor allem in Verbindung mit soliden sprachlichen Kenntnissen stellt dies ausgezeichnete Voraussetzungen für eine Karriere in mehreren Berufsfeldern dar, wie beispielsweise in Kultureinrichtungen, in Museen, im diplomatischen Dienst, in Bibliotheken sowie im interkulturellen Sozialsektor als Integrations-Projektleiter oder als Albanienexperten im Pressewesen oder in einer wirtschaftsnahen Einrichtung im Zuge der EU-Osterweiterung. Auch hier empfiehlt es sich, so früh wie möglich nach studienergänzenden Fortbildungsmöglichkeiten, wie Praktika, Volontariate etc. ausschauzuhalten und Kontakte zu knüpfen, um praktische Berufserfahrungen zu sammeln und somit den Einstieg ins Berufsleben zu erleichtern.

Sofern bereits zu Beginn des Studiums ein besonderer Fokus auf das Erlernen von Standard-Albanisch bis hin zum Niveau C1/C2 nach dem Gemeinsamen Europäischen Referenzrahmen für Sprachen gelegt wird, ist auch eine Tätigkeit als Dolmetscher bzw. Übersetzer denkbar. Der Beruf des Dolmetschers bzw. Übersetzers ist in Deutschland nicht gesetzlich geschützt, sodass prinzipiell jeder mit ausreichend guten Sprachkenntnissen diese Tätigkeit ausüben kann. Nichtsdestotrotz werden eidesstattlich geprüfte Dolmetscher bzw. Übersetzer bevorzugt und sind vor allem bei weniger bekannten Sprachen, wie Albanisch, gefragt. Ein Studium im Masterstudiengang Albanologie sowie die erfolgreiche Teilnahme an Sprachkursen kann daher als Nachweis für eine qualifizierte Ausbildung und den Erwerb qualifizierender Landes-, Kultur- und vor allem Sprachkenntnisse dienen, was für die Teilnahme an einer staatlichen Übersetzerprüfung Voraussetzung ist.

### Erwünschtes Profil

Wer sich für den Master Albanologie interessiert, sollte neben einem vertieften Verständnis für sprach-, literatur- und kulturwissenschaftlichen Fragestellungen auch die Motivation zu eigener wissenschaftlicher Forschung mitbringen. Unabdingbar sind darüber hinaus die Fähigkeit und Bereitschaft, sich mit den interdisziplinären Aspekten des Faches reflektiert und kritisch auseinanderzusetzen.

## Fakten auf einen Blick

Studiengang: Albanologie (Master)

Abschlussgrad: Master of Arts (M.A.)

Fachtyp: Hauptfach

Regelstudienzeit: 4 Fachsemester

Studienform: Weiterführendes Studium mit berufsqualifizierendem Abschluss

Studienbeginn: nur im Wintersemester

Studiensprache: Deutsch

Fakultät: Fakultät für Sprach- und Literaturwissenschaften

Fächergruppe: Sprach- und Kulturwissenschaft

ECTS: 120

Beiträge: Die Universität erhebt für das Studentenwerk München den Grundbeitrag sowie den Solidarbeitrag Semesterticket. Nähere Informationen s. Beiträge für das Studentenwerk

Anmerkungen: Ein-Fach-Masterstudiengang im Umfang von 120 ECTS-Punkten.

## Bewerbung und Zulassung

Zulassungsmodus 1. Semester: Freie Studiengänge

Zulassungsmodus höheres Semester: Freier Zugang

Zugangsdetails: Voraussetzung für die Immatrikulation in diesen Masterstudiengang ist der Nachweis eines berufsqualifizierenden Hochschulabschlusses oder eines gleichwertigen Abschlusses aus dem Inland oder Ausland in einem mindestens sechssemestrigen Studiengang der Fachrichtung Allgemeine und Indogermanische Sprachwissenschaft, Albanologie, Romanistik, Slavistik oder eines verwandten Faches. Als weitere Voraussetzung wird der Nachweis der selbstständigen Sprachverwendung des Albanischen (Stufe B1 des Gemeinsamen Europäischen Referenzrahmens für Sprachen) verlangt. Studierende aus dem Ausland, vor allem aus dem albanischsprachigen Raum werden darauf hingewiesen, dass sie unter bestimmten Bedingungen den erforderlichen Nachweis der Deutschkenntnisse für ihre Immatrikulation in den Masterstudiengang "Albanologie" mindestens auf das Niveau B1 GER vorlegen müssen. Es wird zudem erwartet, dass sie ihr Deutschniveau bis zum Abschluss ihres Masterstudiums auf C1 angehoben haben sollten. Es ist kein Eignungsverfahren vorgesehen, aber allen Interessenten wird dringend nahegelegt, vor Aufnahme des Studiums ein ausführliches Beratungsgespräch bzw. eine ausführliche Beratung per Email zu suchen: Prof. Dr. Bardhyl Demiraj ( demiraj@lmu.de ) PD Dr. Peter-Arnold Mumm ( mumm@lmu.de )

Link zum Fach: Master Albanologie

## Ihr Weg zum Studienplatz

## Der Studiengang im Detail

### Studienaufbau

Entsprechend des Programms der MA Albanologie ist das Lehrangebot stark interdisziplinär ausgerichtet. Grob schematisch lassen sich die Einzelbereiche wie folgt zuordnen:

### Empfohlener Studienverlauf

1. Semester

- P 1/I: Grundzüge der Albanologie
- P 2: Variationstypologie
- P 3: Sprache und Kultur I
- P 4: Strukturelle Linguistik des Albanischen I

2. Semester

- P 1/II: Grundzüge der Albanologie
- P 5: Albanische Philologie
- P 6: Sprache und Kultur I
- P 7: Strukturelle Linguistik des Albanischen II

3. Semester

- P 8: Sprachkonakt
- P 9: Praxisorientierte Forschung
- P 10: Sprache und Kultur II

4. Semester

- P 11: Abschlussmodul
- \*WP 1 - WP 7

\*Es darf nur entweder ein Wahlpflichtmodul (6 ECTS) aus dem Gemeinsamen Geistes- und Sozialwissenschaftlichen Profilbereich oder aus den Wahlpflichtmodulen (WP1 bis WP7) gewählt werden.

Veranstaltungen, die Studierende im Rahmen eines vorangehenden Studiums (BA, MA und Sonstiges) mit Erfolg abgelegt haben, werden von Fall zu Fall von der/dem jeweiligen DozentIn berücksichtigt und entsprechend vollständig oder teilweise auch bei der ECTS-Punktevergabe in MA Studium „Albanologie“ anerkannt.

### Studienaufbau und Module

Das nachfolgende Modell stellt keine obligatorische, wohl aber eine empfohlene Studienverlaufsbeschreibung dar, die je nach Interessenschwerpunkt und in Absprache mit dem Studiengangskoordinator und dem Fachleiter modifiziert werden kann.

1. Erstes Fachsemester (Wintersemester)

Pflichtveranstaltungen zu den Bereichen (P 1, P 2, P 3 und P 4):

- (a) Grundzüge der Albanologie („Einführung in die Albanologie“ – 2 SWS)
- (b) Variationstypologie („Variationslinguistik des Albanischen“ und „Feldforschung“ – 2+2 SWS)
- (c) Sprache und Kultur I („Albanisch 3“ und „Albanische Literaturwissenschaft“ – 2+2 SWS)
- (d) Strukturelle Linguistik des Albanischen I („Sprachwandel und interne Rekonstruktion I“ und „Morphologischer Aufbau des Albanischen“ – 2+2 SWS)

2. Fachsemester (Sommersemester)

Pflichtveranstaltungen zu den Bereichen (P 1, P 5, P 6 und P 7):

- (a) Grundzüge der Albanologie („Vertiefung Albanologie“ – 2 SWS)
- (b) Albanische Philologie („Schriftkultur und Textedition“ und „Albanische Lektüre“ – 2+2 SWS)
- (c) Sprache und Kultur II („Albanisch 4“ und „Albanische Sprechfertigkeiten“ – 2+2 SWS)
- (d) Strukturelle Linguistik des Albanischen II („Sprachwandel und interne Rekonstruktion II“ und „Der albanische Satzbau“ – 2+2 SWS)

3. Fachsemester (Wintersemester)

Pflichtveranstaltungen zu den Bereichen (P 8, P 9 und P 10):

- (a) Sprachkontakt („Sprachkontakt und kulturelle Identität“ und „Albanische Landeskunde“ – 2+2 SWS)
- (b) Praxisorientierte Forschung („Vorbereitungskolloquium“ – 2 SWS)
- (c) Sprache und Kultur II („Albanologisches Praxisprojekt“ und „Albanisches Gewohnheitsrecht“ – 0,5+2 SWS)
- Wahlpflichtveranstaltungen zu den Bereichen (WP 1 bis WP 7):
- (d.a) Eine Nachbar-/Balkansprache (wahlweise: „Italienisch 1“ oder „Rumänisch 1.1+1.2“ oder „Serbisch-Kroatisch 1.1 +1.2“ oder “Bulgarisch 1.1+1.2” oder „Neugriechisch 1.1+1.2“ oder „Türkisch 1“ – 4 / 2+2 SWS) oder:
- (d.b) Angewandte Strukturierung und Analyse linguistischer Daten („Theorie der Datenstrukturierung“ und „Übungen zur Datenstrukturierung“ – 2+2 SWS) oder:
- (d.c) Ein Wahlpflichtmodul im Umfang von 6 ECTS aus dem [Gemeinsamen Geistes- und Sozialwissenschaftlichen Profilbereich](https://www.profilbereich-gs.uni-muenchen.de/index.html).

4. Fachsemester (Sommersemester)

- Im vierten Semester (P 11) wird die Masterarbeit (20 Wochen, ca. 100.000 - 120.000 Zeichen) geschrieben und in einer Disputation (45-60 min) verteidigt.

### Modulhandbuch

## Institut für Vergleichende und Indogermanische Sprachwissenschaft sowie Albanologie

Sprechstunden, Aushänge, Änderungen des Lehrangebots

## Fachstudienberatung MA Albanologie

Inhaltliche und spezifische Fragen des Studiums, Studienaufbau, Stundenplan, fachliche Schwerpunkte

## Prüfungsamt für Geistes- und Sozialwissenschaften

Prüfungsangelegenheiten, Prüfungsanmeldung, Semesteranrechnungsbescheide