## About the program

The Master's in Neurosciences is hosted by the Faculty of Biology at Ludwig-Maximilians-Universität München and embedded within the broader academic and research ecosystem of the Graduate School of Systemic Neurosciences. This connection gives students the best of both worlds: the academic standing and institutional framework of one of Germany's leading universities, combined with access to the GSN's extensive research network, interdisciplinary community, and administrative expertise.

In practice, this means students benefit from a program that is both firmly grounded in rigorous biological science and open to the full breadth of neuroscience research represented across the GSN and its affiliated institutes.

Curriculum information and further details are available on the Faculty of Biology program page.

## How to apply

Applications to the Master's in Neurosciences are managed by the GSN. Find everything you need – eligibility requirements, deadlines, required documents, and the step-by-step guide to the application process – on the [GSN application page](../../become-a-gsn-student/).

## Teaching concept – career-tailored education

How does the brain work? While cellular and molecular neuroscience have advanced enormously, and modern in vivo techniques now allow non-invasive observation of brain activity in living humans, the brain as a complex, integrated system remains one of science's great frontiers.

At the GSN, we believe this complexity can only be addressed by combining approaches and methods from across the neurosciences. Our teaching faculty – including GSN researchers and guest lecturers from leading external institutions – bring exactly this breadth to the classroom.

Students graduate with a strong grounding in the molecular, cellular, and systemic principles of neurobiology. This foundation equips them to understand neuron–neuron interaction, the dynamics of neuron–glia signalling, information transfer in simple and complex circuits, the interplay between brain regions, and ultimately the integrated function of the human brain.

## ﻿Two academic tracks ﻿

Since 2018, the GSN curriculum has offered students greater flexibility and the opportunity to sharpen their academic profile. Students choose between two dedicated tracks:

- Systemic-Cellular-Molecular Neuroscience - for students whose focus lies in the biological and experimental dimensions of brain science

- Computational Neuroscience - for students drawn to mathematical modelling, theory, and data-driven approaches

Whichever track a student selects, they will also complete coursework in the other area at a broader level – ensuring a well-rounded scientific foundation regardless of specialisation.

## Three pillars of training

Our teaching concept is built around three pillars, designed to give students both the knowledge and practical skills to thrive in neuroscience research and beyond.

### 1. Comprehensive education

The curriculum spans the core domains of systemic neurobiology, molecular and cellular neurobiology, computational neuroscience, and neurophilosophy. The course of study takes students on a guided journey through the full breadth of modern neuroscience, beginning with the biological principles of brain structure and neuronal communication, and progressively broadening towards cognition, higher brain functions, computational methods, and the philosophical dimensions of the discipline. This structured progression ensures that students build knowledge coherently, with each stage informed by what came before.

In the first two semesters, core courses are shared with GSN Fast-track and PhD students, fostering an integrated and collaborative learning environment from the very start.

### 2. Individual research training

Hands-on research begins from day one. Each semester, students complete an individual research project, giving them early exposure to participating laboratories and research teams. Alongside mandatory courses, students choose from a wide range of methods and interdisciplinary modules. The programme culminates in a Master's thesis.

### 3. Complementary skills

Scientific excellence alone is not enough. In their second year, students gain first-hand teaching experience by tutoring junior peers – earning credits while developing as educators. Modular workshops cover academic transferable skills including scientific writing, presentation, communication, and time management, preparing students for the full range of career paths open to them.

## The GSN advantage

Being embedded in the GSN means more than access to a research network. It means joining a living scientific community.

- Interdisciplinary mentoring – students benefit from guidance by researchers spanning experimental, computational, clinical, and theoretical neuroscience
- Shared learning environment – core courses alongside Fast-track and PhD students create a genuinely integrated academic experience from day one
- Research network – access to over 160 faculty members across LMU Munich, TUM, Max Planck Society, and Helmholtz Center Munich
- Community and events – retreats, seminars, symposia, and social events that build lasting connections across cohorts and disciplines
- Peer mentoring – incoming students are paired with a senior GSN student through the GSN Peer Mentoring Program, offering support from day one

## Study and administration

Log into [MyGSN](https://www.portal.graduatecenter.lmu.de/gsn/) to access the following resources

[Study regulations](https://cms-cdn.lmu.de/media/contenthub/amtliche-veroeffentlichungen/1361-19ns-ma-2018-ps00.pdf) & infos
Detailed program rules, milestones, and degree requirements.

Student forms & checklists
Required documents and guidance for enrollment, progress, and completion.

Faculty forms & guest travel
Administrative forms for faculty processes and travel reimbursements.

Seminars & courses
Courses, schedules, and registration details for GSN seminars and workshops.

## Program coordinating office

Head of M.Sc. Neuroscience Examination Committee: Prof. Dr. Anton Sirota

Program Coordinator: Dr. Alexander Kaiser

Email:: master-neurosci@lmu.de

Adress: LMU BioCenter Großhadernerstr. 2 D-82152 Martinsried