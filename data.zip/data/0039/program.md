## Beschreibung des Studienfachs

Im Fach Deutsch als Fremdsprache geht es in Forschung und Lehre um die Frage, wie deutsche Sprache, Literatur und Kultur aus der Fremdperspektive vermittelt und verständlich gemacht werden können. Die inhaltlichen Schwerpunkte des konsekutiven und stärker forschungsorientierten Masterstudiengangs Deutsch als Fremdsprache liegen in den Bereichen der Spracherwerbs- und Mehrsprachigkeits-forschung mit Vertiefungen in Medien- ,Berufs- und Fachsprachendidaktik sowie einer um interkulturelle und kulturwissenschaftliche Fragen erweiterten Philologie literarischer Sprach- und Textzeugnisse. Der Masterstudiengang vermittelt Studierenden aus dem In- und Ausland eine gehobene Qualifikation insbesondere für die Sprach-, Literatur- und Kulturvermittlung (DAAD-Lektorate, Goethe-Institut, Robert-Bosch-Stiftung, Auslandsgermanistik, deutschsprachige Schulen im Ausland, Deutsch als Zweitsprache etc.), für interkulturelles Management und interkulturelle Mediation in Verlagen, Medien und politischen Organisationen und im Bereich des Journalismus, für Wissenschaftsorganisation und Wissenschaftsmanagement in internationalen Institutionen sowie für andere Bereiche, in denen interkulturelle Kommunikation und grenzüberschreitende Verständigung von Bedeutung sind.

### Tätigkeits- und Berufsfelder

Informationen zu möglichen Berufsfeldern finden Sie unter: <https://www.daf.uni-muenchen.de/studium/studiengaenge1/ma/berufsfeld/index.html>

### Erwünschtes Profil

Wir suchen hoch motivierte Absolventinnen und Absolventen der Fächer Deutsch als Fremdsprache, Germanistik oder aus benachbarten Bereichen aus dem In- und Ausland. Sie haben wissenschaftliches Interesse, sind engagiert, kreativ und leistungsbereit. Wenn Sie Ihr Studium mit sehr gutem Ergebnis abgeschlossen haben und Deutsch auf hohem Niveau sprechen und schreiben, dann ist dieser Studiengang genau das Richtige für Sie.

## Fakten auf einen Blick

Studiengang: Deutsch als Fremdsprache (Master)

Abschlussgrad: Master of Arts (M.A.)

Fachtyp: Hauptfach

Regelstudienzeit: 4 Fachsemester

Studienform: Weiterführendes Studium mit berufsqualifizierendem Abschluss

Studienbeginn: nur im Wintersemester

Studiensprache: Deutsch

Fakultät: Fakultät für Sprach- und Literaturwissenschaften

Fächergruppe: Sprach- und Kulturwissenschaft

ECTS: 120

Anmerkungen: Ein-Fach-Masterstudiengang mit 120 ECTS.

## Bewerbung und Zulassung

Zulassungsmodus 1. Semester: Eignungsverfahren

Zulassungsmodus höheres Semester: Eignungsverfahren

Zugangsdetails: Für die Aufnahme in den Masterstudiengang Deutsch als Fremdsprache wird neben einem ersten berufsqualifizierenden Hochschulabschluss im Umfang von mindestens 180 ECTS-Punkten oder einem gleichwertigen Abschluss aus dem Inland oder Ausland der Fachrichtung Philologie, Philosophie, Linguistik oder aus kulturwissenschaftlichen Disziplinen die erfolgreiche Teilnahme an einem Eignungsverfahren vorausgesetzt. Fristen und weitere Informationen hier .

Link zum Fach: Master Deutsch als Fremdsprache

## Ihr Weg zum Studienplatz

## Der Studiengang im Detail

### Studienaufbau

Die inhaltlichen Schwerpunkte des Masterstudiengangs liegen in den Bereichen der Spracherwerbs- und Mehrsprachigkeitsforschung mit Vertiefungen in Medien-, Berufs- und Fachsprachendidaktik. Interkulturelle und kulturwissenschaftlich orientierte Philologien erweitern das Wissens- und Kenntnisspektrum. Wichtige Themen aus den Bereichen der Linguistik und der Literaturwissenschaft werden als Wahlveranstaltungen angeboten. Die Ausbildung ist vorwiegend wissenschaftlich, aber auch immer berufsbezogen, daher werden wichtige Praxis- und Berufsfelder im Lehren und Lernen von Deutsch als Fremdsprache berücksichtigt, wie Kulturvermittlung und Kulturpolitik, die ein abgeschlossenes Master-Studium als Eingangsqualifikation verlangen.

Der Studiengang gliedert sich in Pflicht- und Wahlpflichtmodule; die Pflichtmodule vermitteln im ersten Studienjahr Kenntnisse aus den Bereichen der Linguistik, Mehrsprachigkeitsforschung sowie Sprachlehr- und Sprachlernforschung. Danach besteht im dritten Semester durch die Wahl eines medien- oder berufs- und fachsprachendidaktischen Moduls die Möglichkeit zur Spezialisierung.

Im ersten und zweiten Fachsemester werden die philologischen Wissensbestände des Faches vermittelt, wobei dazu im zweiten Semester alternativ textlinguistische Inhalte studiert werden können.

Alle Semester werden durch studienpraktische und anwendungsbezogene Übungen, die Schlüsselkompetenzen des Studienfaches sowie Berufsfeldes Deutsch als Fremdsprache vermitteln, begleitet. Im ersten Semester werden im Brückenmodul Wissenslücken aus dem vorangehenden Studium geschlossen.

Detaillierte Informationen und Studienpläne finden Sie unter: [https://www.daf.uni-muenchen.de/studium/studiengaenge1/ma/inhalte2019/index.html](https://www.daf.uni-muenchen.de/studium/studiengaenge1/ma/inhalte2019/index.html )

Nebenfächer

Ein-Fach-Masterstudiengang mit 120 ECTS. Die Immatrikulation in ein Nebenfach ist nicht möglich. Stattdessen können im Verlauf des Studiums Module aus dem "[Gemeinsamen Geistes- und Sozialwissenschaftlicher Profilbereich](https://www.profilbereich-gs.uni-muenchen.de/index.html)" im Umfang von insgesamt 30 ECTS-Punkten gewählt werden. Weitere Informationen dazu: <https://www.daf.uni-muenchen.de/studium/studiengaenge1/ma/profil/index.html>

### Unterrichtssprache

Deutsch

### Prüfungs- und Studienordnungen

[Prüfungs- und Studienordnung der Ludwig-Maximilians-Universität München für den Masterstudiengang Deutsch als Fremdsprache (2019) vom 11. Februar 2020 (PDF, 140 KB)](https://cms-cdn.lmu.de/media/contenthub/amtliche-veroeffentlichungen/1395-13daf-ma-2019-ps00.pdf)[Prüfungs- und Studienordnung der Ludwig-Maximilians-Universität München für den Internationalen Masterstudiengang Deutsch als Fremdsprache (2012) vom 28. Januar 2013 (PDF, 187 KB)](https://cms-cdn.lmu.de/media/contenthub/amtliche-veroeffentlichungen/917-13daf-ma-2012-ps00.pdf)[Prüfungs- und Studienordnung der Ludwig-Maximilians-Universität München für den Internationalen Masterstudiengang Deutsch als Fremdsprache vom 8. September 2010 (PDF, 138 KB)](https://cms-cdn.lmu.de/media/contenthub/amtliche-veroeffentlichungen/566-13daf-ma-10-ps00.pdf)[Satzung über das Eignungsverfahren für den Masterstudiengang Deutsch als Fremdsprache an der Ludwig-Maximilians-Universität München vom 29. Juli 2019 (PDF, 34 KB)](https://cms-cdn.lmu.de/media/contenthub/amtliche-veroeffentlichungen/1355-eign-master-daf.pdf)

## Deutsch als Fremdsprache

Sprechstunden, Aushänge, Änderungen des Lehrangebots

## Fachstudienberatung Deutsch als Fremdsprache

Inhaltliche und spezifische Fragen des Studiums, Studienaufbau, Stundenplan, fachliche Schwerpunkte

## Prüfungsamt für Geistes- und Sozialwissenschaften

Prüfungsangelegenheiten, Prüfungsanmeldung, Semesteranrechnungsbescheide