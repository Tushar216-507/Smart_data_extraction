## Beschreibung des Studienfachs

Das BA Hauptfach Griechische Studien verwirklicht das Modell einer integrierten Gräzistik, die sich mit der griechischen Literatur der Antike, der byzantinischen Zeit und der Neuzeit befasst. Der Studiengang setzt bei der Vermittlung von grundlegenden Sprachkenntnissen an oder baut auf sie auf (je nach Vorkenntnissen), und zielt ab auf eine umfassende Erschließungskompetenz literarischer Texte der genannten Epochen. Der Studiengang bietet neben der Vermittlung allgemeiner Fähigkeiten in Informationsbeschaffung und Recherche, insbesondere durch Datenbanken, anhand von literaturgeschichtlichen Themenbereichen die für den gesamten Bereich der Griechischen Studien erforderlichen methodischen Kompetenzen. Die Ausbildung wird durch kulturgeschichtliche und medienkundliche Anteile im Pflichtbereich ergänzt.

### Tätigkeits- und Berufsfelder

Der Studiengang bereitet vor auf die Beschäftigung an Universitäten und Akademien, in Verlagen, Dokumentation und Archiv, der Erwachsenenbildung, der Veranstaltungsorganisation, der Presse- und Öffentlichkeitsarbeit sowie allen Gebieten des cultural management.

## Fakten auf einen Blick

Studiengang: Griechische Studien (Bachelor)

Abschlussgrad: Bachelor of Arts (B.A.)

Fachtyp: Hauptfach

Regelstudienzeit: 6 Fachsemester

Studienform: Grundständiges Studium mit erstem berufsqualifizierenden Abschluss

Studienbeginn: nur im Wintersemester

Studiensprache: Deutsch

Konsekutiver Master möglich: Ja

Fakultät: Fakultät für Sprach- und Literaturwissenschaften

Fächergruppe: Sprach- und Kulturwissenschaft

ECTS: 120

## Bewerbung und Zulassung

Formale Studienvoraussetzung: Hochschulzugangsberechtigung

Zulassungsmodus 1. Semester: Freie Studiengänge

Zulassungsmodus höheres Semester: Freier Zugang

Link zum Fach: Studiengänge Klassische Philologie

## Ihr Weg zum Studienplatz

## Der Studiengang im Detail

### Studienaufbau

Das Studium ist für eine Regelstudienzeit von sechs Semestern konzipiert. Die Pflichtmodule (P) müssen von allen Studierenden absolviert werden. Die Auswahlmöglichkeit zwischen den Wahlpflichtmodulen (WP) 1 bis 3, 4 bis 6, 10/I-II oder 11/I–II nimmt auf bereits vorhandene Sprachkenntnisse (Alt- und/oder Neugriechisch) bzw. auf den Schwerpunkt des Studiums Rücksicht (Altgriechische Philologie, Byzantinistik oder Neogräzistik). Durch die Wahlpflichtmodule 7 bis 23 wird eine Schwerpunktbildung in den Bereichen (Alt)griechische Philologie, Byzantinistik und Neogräzistik ermöglicht. Das Studium schließt mit der Erstellung einer Bachelorarbeit ab.

### Module und Lehrveranstaltungen

1. Semester. Zu belegen: P 1 und P2, WP 1 oder WP 2 oder WP 3

P 1 Grundlagen der Griechischen Studien I (Basis), 9 CP

- P 1.1 Griechische Literaturgeschichte Übung, 2 SWS, 4 CP
- P 1.2 Griechische Literaturgeschichte Tutorium, 1 SWS, 2 CP
- P 1.3 Einführung in die Byzantinistik Übung, 2 SWS, 3 CP

P 2 Informationskompetenz, 3 CP

- P 2.1 Grundlagen wissenschaftlicher Recherche Übung, 1 SWS, 2 CP
- P 2.2 Grundlagen wissenschaftlicher Recherche Tutorium, 1 SWS, 1 CP

WP 1 Griechische Sprache I, 6 CP

- WP 1.1 Einführung in die griechische Sprache und Kultur Ia Übung, 2 SWS, 3 CP
- WP. 1.2 Einführung in die griechische Sprache und Kultur Ib Übung, 2 SWS, 3 CP

WP 2 Neugriechische Sprache I, 6 CP

- WP 2.1 Neugriechische Sprache Ia Übung, 2 SWS, 3 CP
- WP 2.2 Neugriechische Sprache Ib Übung, 2 SWS, 3 CP

WP 3 Altgriechische Autorenlektüre: Prosa, 6 CP

- WP 3.1 Einführung in die Autorenlektüre Ia Übung, 2 SWS, 3 CP
- WP 3.2 Einführung in die Autorenlektüre Ib Übung, 2 SWS, 3 CP

2. Semester. Zu belegen: P 3 und WP 4 oder WP 5 oder WP 6

P 3 Grundlagen der Griechischen Studien II (Fortführung), 12 CP

- P 3.1 Einführung in Mythologie und Religion der Griechen Übung, 2 SWS, 3 CP
- P 3.2 Einführung in die Neogräzistik Übung, 2 SWS, 3 CP
- P 3.3 Einführung in die AVL Übung, 4 SWS, 6 CP

WP 4 Griechische Sprache II, 6 CP

- WP 4.1 Einführung in die griechische Sprache und Kultur IIa Übung, 2 SWS, 3 CP
- WP 4.2 Einführung in die griechische Sprache und Kultur IIb Übung, 2 SWS, 3 CP

WP 5 Neugriechische Sprache II, 6 CP

- WP 5.1 Neugriechische Sprache IIa Übung, 2 SWS, 3 CP
- WP 5.2 Neugriechische Sprache IIb Übung, 2SWS, 3 CP

WP 6 Altgriechische Autorenlektüre: Poesie, 6 CP

- WP 6.1 Einführung in die Autorenlektüre IIa Übung, 2 SWS, 3 CP
- WP 6.2 Einführung in die Autorenlektüre IIb Übung, 2 SWS, 3 CP

3. Semester. Zu belegen: WP 7 oder WP 8 oder WP 9 und WP 10/I oder 11/I

WP 7 Narrative Formen I (Griechische Philologie), 12 CP

- WP 7.1 Das griechische Epos Vorlesung, 2 SWS, 3 CP
- WP 7.2 Intensive Lektüre griechisches Epos Übung, 2 SWS, 3 CP
- WP 7.3 Altgriechische Literatur: Poesie (zur Metho­dik literaturwissenschaftlichen Arbeitens) Basisseminar, 2 SWS, 6 CP

WP 8 Narrative Formen I (Byzantinistik), 12 CP

- WP 8.1 Das griechische Epos Vorlesung, 2 SWS, 3 CP
- WP 8.2 Intensive Lektüre byzantinische Prosa Übung, 2 SWS, 3CP
- WP 8.3 Byzantinische Literaturwissenschaft: Gattungsproblematik Basisseminar, 2 SWS, 6 CP

WP 9 Narrative Formen I (Neogräzistik), 12 CP

- WP 9.1 Das griechische Epos Vorlesung, 2 SWS, 3 CP
- WP 9.2 Intensive Lektüre neugriechische Prosa Übung, 2 SWS, 3 CP
- WP 9.3 Neugriechische Literaturwissenschaft: Gattungsproblematik Basisseminar, 2 SWS, 6 CP

WP 10/I Griechische Grammatik, 6 CP

- WP 10.1 Griechische Morphologie Übung, 3 SWS, 6 CP

WP 11/I Neugriechische Sprache III, 6 CP

- WP 11.1 Neugriechische Sprache IIIa Übung, 2 SWS, 3 CP
- WP 11.2 Neugriechische Sprache IIIb Übung, 2 SWS, 3 CP

4. Semester. Zu belegen: WP 12 oder WP 13 oder WP 14 und WP 10/II oder 11/II

WP 12 Narrative Formen II (Griechische Philologie), 12 CP

- WP 12.1 Die griechische Historiographie Vorlesung, 2 SWS, 3 CP
- WP 12.2 Intensive Lektüre griechische Histo­riographie Übung, 2 SWS, 3 CP
- WP 12.3 Altgriechische Literatur: Prosa (zur Methodik literaturwissenschaftlichen Arbeitens) Basisseminar, 2 SWS, 6 CP

WP 13 Narrative Formen II (Byzantinistik), 12 CP

- WP 13.1 Die griechische Historiographie Vorlesung, 2 SWS, 3 CP
- WP 13.2 Intensive Lektüre byzantinische Histo­riographie Übung, 2 SWS, 3 CP
- WP 13.3 Byzantinische Historiographie Basisseminar, 2 SWS, 3 CP

WP 14 Narrative Formen II (Neogräzistik), 12 CP

- WP 14.1 Die griechische Historiographie Vorlesung, 2 SWS, 3 CP
- WP 14.2 Intensive Lektüre neugriechische Essayistik Übung, 2 SWS, 3 CP
- WP 14.3 Neugriechische Literaturwissenschaft:Literaturgeschichtschreibung Basisseminar, 2 SWS, 6 CP

WP 10/II Griechische Grammatik, 6 CP

- WP 10.2 Griechische Syntax Übung, 3 SWS, 6 CP

WP 11/II Neugriechische Sprache III, 6 CP

- WP 11.3 Neugriechische Sprache IIIc Übung, 2 SWS, 3 CP
- WP 11.4 Neugriechische Sprache IIId Übung, 2 SWS, 3 CP

5. Semester. Zu belegen: WP 15 oder WP 16 oder WP 17 und WP 18/I oder WP 19/I oder WP 20/I

WP 15 Diskursive Formen I (Griechische Philologie), 12 CP

- WP 15.1 Das griechische Drama Vorlesung, 2 SWS, 3 CP
- WP 15.2 Intensive Lektüre griechisches Drama Übung, 2 SWS, 3 CP
- WP 15.3 Extensive Lektüre griechisches Drama Übung, 3 SWS, 6 CP

WP 16 Diskursive Formen I (Byzantinistik), 12 CP

- WP 16.1 Byzantinische Literatur Vorlesung, 2 SWS, 3 CP
- WP 16.2 Intensive Lektüre Byzantinische Lite­ratur Übung, 2 SWS, 3 CP
- WP 16.3 Extensive Lektüre griechisches Drama Übung, 3 SWS, 6 CP

WP 17 Diskursive Formen I (Neogräzistik), 12 CP

- WP 17.1 Neugriechische Literatur I Vorlesung, 2 SWS, 3 CP
- WP 17.2 Intensive Lektüre neugriechische Lite­ratur I Übung, 2 SWS, 3 CP
- WP 17.3 Extensive Lektüre griechisches Drama Übung, 3 SWS, 6 CP

WP 18/I Forschung und Rezeption (Griechische Philologie), 6 CP

- WP 18.1 Forschungsprobleme in der griechischen Literaturwissenschaft Hauptseminar, 2 SWS, 6 CP

WP 19/I Forschung und Rezeption (Byzantinistik), 6 CP

- WP 19.1 Forschungsprobleme in der Byzantinistik Hauptseminar, 2 SWS, 6 CP

WP 20/I Forschung und Rezeption (Neogräzistik), 6 CP

- WP 20.1 Forschungsprobleme in der Neogräzistik Hauptseminar, 2 SWS, 6 CP

6. Semester. Zu belegen: WP 21 oder WP 22 oder WP 23 und WP 18/II oder WP 19/II oder WP 20/II und BA

WP 21 Diskursive Formen II (Griechische Philologie), 12 CP

- WP 21.1 Griechische Philosophie und RhetorikVorlesung, 2 SWS, 3 CP
- WP 21.2 Intensive Lektüre griechische Philosophie und Rhetorik Übung, 2 SWS, 3 CP
- WP 21.3 Extensive Lektüre griechische Philosophie und Rhetorik Übung, 2 SWS, 6 CP

WP 22 Diskursive Formen II (Byzantinistik), 12 CP

- WP 22.1 Byzantinische Kulturgeschichte Vorlesung, 2 SWS, 3 CP
- WP 22.2 Intensive Lektüre byzantinische Kulturgeschichte Übung, 2 SWS, 3 CP
- WP 22.3 Extensive Lektüre griechische Philosophie und Rhetorik Übung, 3 SWS, 6 CP

WP 23 Diskursive Formen II (Neogräzistik), 12 CP

- WP 23.1 Neugriechische Literatur II Vorlesung, 2 SWS, 3 CP
- WP 23.2 Intensive Lektüre neugriechische Literatur II Übung, 2 SWS, 3 CP
- WP 23.3 Extensive Lektüre griechische Philo­sophie und Rhetorik Übung, 3 SWS, 6 CP

WP 18/II Forschung und Rezeption (Griechische Philologie), 6 CP

- WP 18.2 Übung zur Rezeption der griechischen Literatur Übung, 2 SWS, 3 CP
- WP 18.3 Methodenkolloquium zur griechischen Literaturwissenschaft, 2 SWS, 3 CP

WP 19/II Forschung und Rezeption (Byzantinistik), 6 CP

- WP 19.2 Forschungsprobleme der byzantinischen Kultur- und Kunstgeschichte Übung, 2 SWS, 3 CP
- WP 19.3 Methodenkolloquium zur Byzantinistik, 2 SWS, 3 CP

WP 20/II Forschung und Rezeption (Neogräzistik), 6 CP

- WP 20.2 Übung zur Rezeption der neugriechischen Literatur Übung, 2 SWS, 3 CP
- WP 20.3 Methodenkolloquium zur Neogräzistik, 2 SWS, 3 CP

P 4 Abschlussmodul, 12 CP

- BA-Arbeit, 12 CP

### Unterrichtssprache

Deutsch

### Prüfungs- und Studienordnungen

[Zweite Satzung zur Änderung der Prüfungs- und Studienordnung der Ludwig-Maximilians-Universität München für den Bachelorstudiengang Griechische Studien vom 3. November 2010 (PDF, 19 KB)](https://cms-cdn.lmu.de/media/contenthub/amtliche-veroeffentlichungen/656-13gs-ba-10-ps02.pdf)[Satzung zur Änderung der Prüfungs- und Studienordnung der Ludwig-Maximilians-Universität München für den Bachelorstudiengang Griechische Studien vom 28. Oktober 2010 (PDF, 19 KB)](https://cms-cdn.lmu.de/media/contenthub/amtliche-veroeffentlichungen/628-13gs-ba-10-ps01.pdf)[Prüfungs- und Studienordnung der Ludwig-Maximilians-Universität München für den Bachelorstudiengang Griechische Studien vom 22. März 2010 (PDF, 150 KB)](https://cms-cdn.lmu.de/media/contenthub/amtliche-veroeffentlichungen/512-13gs-ba-10-ps00.pdf)[Satzung zur Änderung der Prüfungs- und Studienordnung der Ludwig-Maximilians-Universität München für den Bachelorstudiengang Griechische Studien vom 21. Oktober 2009 (PDF, 19 KB)](https://cms-cdn.lmu.de/media/contenthub/amtliche-veroeffentlichungen/459-13gs-ba-09-ps01.pdf)[Prüfungs- und Studienordnung der Ludwig-Maximilians-Universität München für den Bachelorstudiengang Griechische Studien vom 29. September 2009 (PDF, 144 KB)](https://cms-cdn.lmu.de/media/contenthub/amtliche-veroeffentlichungen/413-13gs-ba-09-ps00.pdf)

## Nebenfächer

Als Nebenfach wählbar ist:

## Angebote zur Studienorientierung

- Studieren probieren, Campustag, Online-Schnupperstunden, uvm.
- Orientierungsangebote
- Wie finde ich heraus, ob mein Wunschstudienfach zu mir passt?

## Institut für Byzantinistik, Byzantinische Kunstgeschichte und Neogräzistik

Sprechstunden, Aushänge, Änderungen des Lehrangebots

## Fachstudienberatung Griechische Studien

### Dr. Martin Vucetic (Studiengangskoordinator)

Inhaltliche und spezifische Fragen des Studiums, Studienaufbau, Stundenplan, fachliche Schwerpunkte

## Zentrale Studienberatung

## Prüfungsamt für Geistes- und Sozialwissenschaften

Prüfungsangelegenheiten, Prüfungsanmeldung, Semesteranrechnungsbescheide