## Beschreibung des Studienfachs

Der stärker forschungsorientierte gemeinsame Masterstudiengang „Geomaterials and Geochemistry“ der Ludwig-Maximilians-Universität München und der Technischen Universität München vermittelt insbesondere vertiefte Kenntnisse und Zusammenhänge aus den Teildisziplinen Mineralogie, Petrologie, Kristallographie, Materialwissenschaften, Geochemie sowie ergänzenden Gebieten und befähigt dazu, komplexe chemische und strukturelle Gesetzmäßigkeiten aus diesen Teilgebieten zu erforschen, zu erkennen und deren Zusammenhänge darzustellen. Die Flexibilität bei der Wahl der Module ermöglicht eine individuelle Spezialisierung innerhalb der Geowissenschaften und eine innovative Vernetzung verschiedener naturwissenschaftlicher Fachrichtungen. Dadurch richtet sich dieser Masterstudiengang auch an Personen, die einen Bachelorabschluss in anderen naturwissenschaftlichen Fachrichtungen erworben haben. Durch die Masterprüfung wird festgestellt, ob die oder der Studierende die Zusammenhänge des Faches überblickt und kritisch beurteilen kann, die Fähigkeit besitzt, dessen wissenschaftliche Methoden und Erkenntnisse anzuwenden und die für den Übergang in die Berufspraxis notwendigen gründlichen Fachkenntnisse erworben hat.

### Tätigkeits- und Berufsfelder

Die breitgefächerte naturwissenschaftliche Grundausbildung und das reichhaltige Spektrum instrumenteller analytischer Methoden befähigt die Absolventen zur Bearbeitung vielfältiger wissenschaftlicher und technischer Fragestellungen.

Beschäftigungsmöglichkeiten bestehen im öffentlichen Bereich (in der Regel mit Promotion) und in den unterschiedlichsten Industriesparten. Zum öffentlichen Bereich gehören Hochschulen, staatliche Forschungseinrichtungen und Ämter (Bereiche Umwelt, Denkmalschutz & Geologie) sowie Materialforschungs- und Prüfanstalten.

Beispiele für Industriesparten mit Beschäftigungsmöglichkeiten für Geomaterialwissenschaftler und Mineralogen sind Glas-, Glaskeramik- und Keramikindustrie, Kristallzüchtungsindustrie, Feuerfestindustrie, Baustoff- und Bindemittelindustrie, Steine- und Erdenindustrie, Chemische Industrie, Elektro- und Elektronikindustrie, Optische Industrie, Abfall- und Recyclingindustrie, Papierindustrie, Düngemittelindustrie, Pharmaindustrie, Schmuckindustrie, Analytische Dienstleistungsunternehmen.

Die Stärke der mineralogisch-geomaterialwissenschaftlichen Ausbildung zeigt sich im Vergleich zur Ausbildung von Chemikern, Physikern, Verfahrenstechnikern, Chemie- oder Keramikingenieuren in der Vielseitigkeit und, ganz wesentlich, in der Erfahrung bei der Behandlung komplexer Stoffsysteme mit einem großen Repertoire an analytischen und synthetischen Arbeitsmethoden.

### Erwünschtes Profil

Der Masterstudiengang „Geomaterialien und Geochemie“ ist nicht zulassungsbeschränkt. Für einen erfolgreichen Studienabschluss sollten Sie aber über gute fachliche Grundlagenkenntnisse in den Geowissenschaften, insbesondere in den Fachrichtungen Mineralogie und Kristallographie, sowie in den naturwissenschaftlichen Fächern Physik, Chemie und Mathematik verfügen. Darüber hinaus sind eigene Erfahrungen im selbstständigen Bearbeiten eines Problems nach wissenschaftlichen Methoden zum Beispiel im Rahmen einer Bachelorarbeit wichtig.

## Fakten auf einen Blick

Studiengang: Geomaterials and Geochemistry (Master)

Abschlussgrad: Master of Science (M.Sc.)

Fachtyp: Hauptfach

Regelstudienzeit: 4 Fachsemester

Studienform: Weiterführendes Studium mit berufsqualifizierendem Abschluss

Studienbeginn: nur im Wintersemester

Studiensprache: Englisch

Fakultät: Fakultät für Geowissenschaften

Fächergruppe: Mathematik und Naturwissenschaften

ECTS: 120

Anmerkungen: Gemeinsamer Studiengang der LMU und der Technischen Universität München; Einschreibung nur an der LMU für beide Hochschulen.

## Bewerbung und Zulassung

Formale Studienvoraussetzung: Hochschulzugangsberechtigung

Zulassungsmodus 1. Semester: Eignungsverfahren

Zulassungsmodus höheres Semester: Eignungsverfahren

Zugangsdetails: Voraussetzung für die Immatrikulation in diesen Masterstudiengang ist der Nachweis eines berufsqualifizierenden Hochschulabschlusses oder eines gleichwertigen Abschlusses aus dem Inland oder Ausland der Fachrichtung Geowissenschaften oder einem Teilbereich der Geowissenschaft (z.B. Mineralogie, Geophysik, Geologie) bzw. einem anderen naturwissenschaftlichen Fach (z.B. Chemie, Physik) sowie die Teilnahme an einem Eignungsverfahren . Die Anmeldung für das Eignungsverfahren ist für das jeweils folgende Wintersemester bis zum 15. Juli (Ausschlussfrist) einzureichen, für nicht-EU/EWR-Bürgerinnen und -Bürger bis 1. März . Weitere Informationen hier .

Link zum Fach: Master Geomaterials and Geochemistry

## Ihr Weg zum Studienplatz

## Der Studiengang im Detail

### Studienaufbau

Siehe dazu:

### Unterrichtssprache

Der Masterstudiengang findet in englischer Sprache statt.

### Prüfungs- und Studienordnungen

[Prüfungs- und Studienordnung der Ludwig-Maximilians-Universität München für den gemeinsamen Masterstudiengang Geomaterials and Geochemistry der Ludwig-Maximilians-Universität München und der Technischen Universität München (2019) vom 6. Dezember 2019 (PDF, 167 KB)](https://cms-cdn.lmu.de/media/contenthub/amtliche-veroeffentlichungen/1366-20gm-ma-2019-ps00.pdf)[Zweite Satzung zur Änderung der Prüfungsordnung für den gemeinsamen Masterstudiengang „Geomaterialien und Geochemie“ der Ludwig-Maximilians-Universität München und der Technischen Universität München (2006) vom 13. August 2014 (PDF, 28 KB)](https://cms-cdn.lmu.de/media/contenthub/amtliche-veroeffentlichungen/1018-20gm-ma-2006-p02.pdf)[Satzung zur Änderung der Prüfungsordnung für den gemeinsamen Masterstudiengang "Geomaterialien und Geochemie" der Ludwig-Maximilians-Universität München und der Technischen Universität München vom 30. Oktober 2007 (PDF, 55 KB)](https://cms-cdn.lmu.de/media/contenthub/amtliche-veroeffentlichungen/223-20gm-ma-2006-p01.pdf)[Prüfungsordnung für den gemeinsamen Masterstudiengang „Geomaterialien und Geochemie“ der Ludwig-Maximilians-Universität München und der Technischen Universität München vom 30. Oktober 2006 (PDF, 160 KB)](https://cms-cdn.lmu.de/media/contenthub/amtliche-veroeffentlichungen/114-20gm-ma-2006-p00.pdf)[Satzung zur Änderung der Studienordnung für den gemeinsamen Masterstudiengang „Geomaterialien und Geochemie“ der Ludwig-Maximilians-Universität München und der Technischen Universität München (2006) vom 13. August 2014 (PDF, 20 KB)](https://cms-cdn.lmu.de/media/contenthub/amtliche-veroeffentlichungen/1019-20gm-ma-2006-s01.pdf)[Studienordnung für den gemeinsamen Masterstudiengang "Geomaterialien und Geochemie" der Ludwig-Maximilians-Universität München und der Technischen Universität München vom 30. Oktober 2007 (PDF, 50 KB)](https://cms-cdn.lmu.de/media/contenthub/amtliche-veroeffentlichungen/224-20gm-ma-2006-s00.pdf)

## Department für Geo- und Umweltwissenschaften

Sprechstunden, Aushänge, Änderungen des Lehrangebots

## Fachstudienberatung Geowissenschaften

### Prof. Dr. Guntram Jordan

Inhaltliche und spezifische Fragen des Studiums, Studienaufbau, Stundenplan, fachliche Schwerpunkte

## Prüfungsamt Naturwissenschaften Innenstadt

Prüfungsangelegenheiten, Prüfungsanmeldung, Semesteranrechnungsbescheide