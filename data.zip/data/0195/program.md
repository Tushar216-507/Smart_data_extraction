## Beschreibung des Studienfachs

Wie der Bachelor- ist auch der Masterstudiengang Soziologie stark forschungsorientiert. Die am Institut vertretene soziologische Forschung wird in einem klar strukturierten und integrativen Studienprogramm abgebildet, das verschiedene Schwerpunktsetzungen ermöglicht. In den Modulen „Soziologische Theorie“, „Soziale Ungleichheit“ und „Methoden“ (hier kann man wählen zwischen qualitativen und/oder quantitativen Methoden) werden Grundlagen gelegt und allgemeines Wissen aus dem Bachelorstudiengang vertieft. Darüber hinaus ist im ersten Studiensemester aus drei verschiedenen Angeboten ein forschungsorientierter Schwerpunktbereich für den weiteren Studienverlauf zu wählen:

- „Gesellschaftstheorie und Zeitdiagnose“,
- „Kultur, Geschlecht, Differenz“ oder
- „Quantitative Ungleichheitsforschung“.

In diesen Schwerpunkten wechseln sich jeweils theoretische und praktisch ausgerichtete Module (wie etwa Forschungsprojektseminare) ab, um den Studierenden Forschungskompetenzen u.a. durch die Mitarbeit an aktuellen Forschungsprojekten zu vermitteln. Indem die Masterstudierenden zugleich gemeinsam vertiefende Grundlagenveranstaltungen besuchen und auch einige Module aus den anderen Schwerpunkten belegen, wird beides möglich: Eine inhaltliche Spezialisierung, die mit der Offenheit für allgemeinsoziologische Fragestellungen und Wissensbestände verbunden ist. Für ein konsekutives Soziologiestudium in München oder auch für einen an den Schwerpunkt-Themen orientierten Studienortwechsel stellt der Masterstudiengang Soziologie an der LMU damit ein attraktives Angebot dar, das den Weg in unterschiedlichste Tätigkeitsfelder eröffnet.

### MA-Schwerpunkt „Gesellschaftstheorie und Zeitdiagnose“

Wer soziologisch über „Gesellschaft“ nachdenkt, wird unweigerlich feststellen, dass eine solche Praxis Teil des Gegenstandes selbst ist: der Gesellschaft eben. In philosophischer Tradition galt „Gesellschaft“ als Sphäre besonderer Allgemeinheit, Gesellschaftstheorie mithin als der allgemeinste Teil soziologischer Theoriebildung. Von dieser Festlegung hat sich das Denken über „Gesellschaft“ längst verabschiedet. Die Gesellschaft, um die es in diesem MA-Schwerpunkt gehen soll, ist als ein besonderer Gegenstand unter anderen Gegenständen der Soziologie zu verstehen. Der Schwerpunkt vermittelt Kenntnisse darüber, wie über gesellschaftliche Strukturen und Prozesse, gesellschaftliche Selbstbeschreibungen und Konflikte um das hegemoniale Bild der „Gesellschaft“ alle sozialen Formen aufeinander bezogen werden. Um die Relation sozialer Phänomene begreifen zu können, bedarf es einer gesellschaftstheoretischen Perspektive. Das heißt ausdrücklich nicht, dass es der Gesellschaftstheorie nur um abstrakte Gegenstände ginge. Vielmehr sollen konkrete Gegenstände der Soziologie sowie ihre Forschung selbst aus einer gesellschaftstheoretischen Perspektive behandelt werden. Dazu gehört maßgeblich auch die Frage nach der zeitdiagnostischen Potenz der Soziologie, die stets zwischen der speziell soziologischen Thematisierung der Gesellschaft und außersoziologischen Formen ihrer Selbstbeschreibung changiert. Ziel des Schwerpunktes ist es, dass seine Absolventinnen und Absolventen mit der Fähigkeit ausgestattet werden, gesellschaftliche Phänomene, Konflikte und Kritik mit gesellschaftstheoretischen Mitteln beobachten zu können – und dass sie dies theoretisch informiert und methodisch kontrolliert einzuholen vermögen.

[Beispielstudienplan Belegung mit Schwerpunkt "Gesellschaftstheorie und Zeitdiagnose"](https://www.soziologie.uni-muenchen.de/studium-und-lehre/studiengaenge1/master11/studienplan_ma-neu_gtuzd.pdf) (PDF, 48 KB)

### MA-Schwerpunkt „Kultur, Geschlecht, Differenz“

Die klassische Kultur- und Wissenssoziologie hat sich für den Zusammenhang zwischen Repräsentationen und gesellschaftlichen Strukturen sowie Prozessen interessiert. Im Unterschied zu einer reinen Kulturwissenschaft ist sie als Soziologie stets mit ihren gesellschaftlichen Bedingungen befasst. Dieser MA-Schwerpunkt erweitert die klassische kultur- und wissenssoziologische Fragestellung um die Frage der sozialen Genese von Identitäten und Differenzen, von Bezeichnungen und Bedeutungen, von Eindeutigkeiten und Uneindeutigkeiten. Er schließt dabei an den klassischen Bestand der Kultur- und Wissenssoziologie ebenso an wie an neuere theoretische und empirische Forschungsfelder, die sich mit der Genese, dem Wandel und den Konflikten von Kategorisierungen beschäftigen. Die entsprechenden Grundlagen werden im ersten Modul vermittelt, durch eine Vorlesung und vertiefenden Veranstaltungen. Das zweite Modul vermittelt vertiefte methodologische Kenntnisse zu Forschungsfeldern rund um ‚Differenzen’, und fokussiert dabei einerseits auf aktuelle gesellschaftliche Dynamiken und andererseits auf Differenzkonflikte als Aspekt sozialer Wirklichkeit. Die empirischen Felder sind vielfältig und reichen von der Geschlechtersoziologie über die Fragen weiterer sozialer Kategorisierungen bis hin zur historischen und systematischen Kultursoziologie sowie der Soziologie der Kunst und ästhetischer Formen. Ein Forschungspraktikum im dritten Modul ermöglicht eigene Forschungsvorhaben im Bereich Kultur, Differenz, Geschlecht. Der Schwerpunkt schließt mit einem internationalen Forschungsworkshop zu einem ausgewählten Thema ab, der durch einen passenden Lektürekurs (internationaler Fachliteratur) vorbereitet wird. Ziel des Schwerpunktes ist es, den Absolventinnen und Absolventen einen theoretisch informierten und methodisch kontrollierten soziologischen Blick auf die Dynamik soziokultureller Formen zu vermitteln.

[Beispielstudienplan Belegung mit Schwerpunkt "Kultur, Differenz, Geschlecht"](https://www.soziologie.uni-muenchen.de/studium-und-lehre/studiengaenge1/master11/studienplan_ma-neu_kgd.pdf) (PDF, 48 KB)

### MA-Schwerpunkt „Quantitative Ungleichheitsforschung“

Dieser Schwerpunkt will für Forschungstätigkeiten aber auch praktische Berufsfelder (etwa Arbeit bei Umfrage- und Forschungsinstituten; Beratungstätigkeiten) im Bereich der quantitativen Forschung zu sozialen Ungleichheiten qualifizieren. Anwendungsfelder bilden dabei gemäß den Forschungsschwerpunkten der beteiligten Lehrbereiche etwa Arbeitsmarkt- und Geschlechterungleichheiten, Ungleichheiten in Familien, Forschung mit Surveys und Experimenten sowie Ungleichheitsmuster in osteuropäischen Gesellschaften. In den ersten drei Modulen werden theoretische und methodische Grundlagen der quantitativen Ungleichheitsforschung gelegt: durch eine Vorlesung zu theoretischen Ansätzen der Ungleichheitsforschung („Analytische Soziologie“) sowie vertiefende Seminare zu Erhebungs- („Datenerhebung“) und Auswertungsmethoden („Fortgeschrittene Methoden“). Die restlichen drei Module sind forschungsorientiert: Die Studierenden erhalten einen Überblick über ein Forschungsfeld („Analyse sozialer Ungleichheit“), eine Anleitung zu eigenem Forschen („Forschungspraktikum“) und Einblicke in die aktuelle Forschung („Forschungskolloquium“).

[Beispielstudienplan Belegung mit Schwerpunkt "Quantitative Ungleichheitsforschung"](https://www.soziologie.uni-muenchen.de/studium-und-lehre/studiengaenge1/master11/studienplan_ma_quanti_v3.pdf) (PDF, 48 KB)

### Tätigkeits- und Berufsfelder

Ausbildungsziel des Masterstudiengangs ist die wissenschaftlich qualifizierte Vorbereitung auf eine Berufstätigkeit in den verschiedenen Anwendungsgebieten der Soziologie. Neben den klassischen Beschäftigungsfeldern der Absolventinnen und Absolventen wie Markt- und Sozialforschung, Tätigkeiten in Organisationen, Beratung und Marketing, Personalwesen, Medien und Kultur eröffnet der Aufbaustudiengang insbesondere Beschäftigungsmöglichkeiten in Forschung und Lehre.

## Fakten auf einen Blick

Studiengang: Soziologie (Master)

Abschlussgrad: Master of Arts (M.A.)

Fachtyp: Hauptfach

Regelstudienzeit: 4 Fachsemester

Studienform: Weiterführendes Studium mit berufsqualifizierendem Abschluss

Studienbeginn: nur im Wintersemester

Studiensprache: Deutsch

Fakultät: Sozialwissenschaftliche Fakultät

Fächergruppe: Rechts-, Wirtschafts- und Sozialwissenschaften

ECTS: 120

Anmerkungen: Ein-Fach-Masterstudiengang mit 120 ECTS.

## Bewerbung und Zulassung

Zulassungsmodus 1. Semester: Eignungsverfahren

Zulassungsmodus höheres Semester: Eignungsverfahren

Zugangsdetails: Für die Aufnahme in den Masterstudiengang Soziologie wird neben einem ersten berufsqualifizierenden Hochschulabschluss oder einem gleichwertigen Abschluss aus dem Inland oder Ausland die erfolgreiche Teilnahme an einem Eignungsverfahren vorausgesetzt. Für den Masterstudiengang Soziologie gilt ein „offener“ Zugang für B.A.- und M.A.-Absolventinnen und -Absolventen aller Disziplinen. Die individuelle Studierfähigkeit wird im Eignungsverfahren geprüft. Der Antrag auf Bewerbung zum Eignungsverfahren ist für das jeweils folgende Wintersemester bis zum 15. Juli beim Department für Soziologie einzureichen (Ausschlussfrist). Weitere Informationen hier .

Link zum Fach: Master Soziologie

## Ihr Weg zum Studienplatz

## Der Studiengang im Detail

### Unterrichtssprache

Die Lehre findet in der Regel auf Deutsch statt. Im Rahmen des Excellence Programms sowie von Gastdozenten werden aber regelmäßig Wahlveranstaltungen in englischer Sprache abgehalten. Ein Großteil der aktuellen soziologischen Forschungsliteratur ist in englischer Sprache verfasst. Umgang mit dieser Fremdsprache findet während des gesamten Studiums statt.

### Prüfungs- und Studienordnungen

## Institut für Soziologie

Sprechstunden, Aushänge, Änderungen des Lehrangebots

## Fachstudienberatung Soziologie

Inhaltliche und spezifische Fragen des Studiums, Studienaufbau, Stundenplan, fachliche Schwerpunkte

## Prüfungsamt für Geistes- und Sozialwissenschaften

Prüfungsangelegenheiten, Prüfungsanmeldung, Semesteranrechnungsbescheide