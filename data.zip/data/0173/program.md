## Beschreibung des Studienfachs

The interdisciplinary MSc Psychology: Learning Sciences and Human Development is offered by the Munich Center of the Learning Sciences (MCLS). It combines fundamental skills and expertise from the fields of psychology and education and has a clear focus on learning, research, and human development. The program promotes a select group of highly motivated students to engage in state-of-the-art research in the internationally emerging field of learning sciences.

### Tätigkeits- und Berufsfelder

The M.Sc. Psychology: Learning Sciences and Human Development prepares and qualifies students for positions in research on learning. Many graduates choose to continue their studies by registering for the MCLS Doctoral Training Program or other Ph.D. degrees in Germany and internationally. Others go on to apply their knowledge in the fields of learning, training or evaluation – in both educational institutions and the business world.

### Erwünschtes Profil

Applicants to the Master’s program Psychology: Learning Sciences and Human Development are expected to demonstrate a genuine and clearly articulated interest in the program’s core content areas. In their application, they must provide evidence of having earned a minimum number of ECTS credits (or equivalent) in the following areas: Learning Sciences and Human Development, Empirical Research Methods, and Academic Skills.

With regard to academic interests, applicants should show a commitment to deepening their expertise in the Learning Sciences through an empirical approach and to broadening their knowledge in an interdisciplinary manner. Beyond subject-specific motivation, applicants are also expected to show a strong interest in engaging with an international student community, conducting independent academic work, participating actively in coursework, and critically reflecting on academic content.

## Fakten auf einen Blick

Studiengang: Psychology: Learning Sciences and Human Development (Master)

Abschlussgrad: Master of Science (M.Sc.)

Fachtyp: Hauptfach

Regelstudienzeit: 4 Fachsemester

Studienform: Weiterführendes Studium mit berufsqualifizierendem Abschluss

Studienbeginn: nur im Wintersemester

Studiensprache: Englisch

Fakultät: Fakultät für Psychologie und Pädagogik

Fächergruppe: Rechts-, Wirtschafts- und Sozialwissenschaften

ECTS: 120

Anmerkungen: Englischsprachiger Ein-Fach-Masterstudiengang mit 120 ECTS.

## Bewerbung und Zulassung

Zulassungsmodus 1. Semester: Eignungsverfahren

Zulassungsmodus höheres Semester: Eignungsverfahren

Zugangsdetails: To enroll in this Master’s program applicants must provide proof of a university degree qualifying for professional work with a scope of at least 180 ECTS (or equivalent) in the field of psychology, education, or a related subject, obtained in Germany or abroad. Additionally, successful participation in an aptitude procedure is required.

Link zum Fach: Master Psychology: Learning Sciences

## Ihr Weg zum Studienplatz

## Der Studiengang im Detail

### Studienaufbau

Compulsory Modules:

- P1: Perspectives on Learning and Development (12 ECTS) focuses on introducing the key theoretical approaches from the fields of cognitive, emotional, educational and developmental psychology as well as machine learning and AI methods.
- P2: Advanced Statistics and Research Methods (12 ECTS) offers students the knowledge and skills needed to plan and implement empirical research as well as to analyse and interpret data.
- P3: Assessment and Diagnostic Methods (12 ECTS) provides students with a comprehensive introduction to the basic principles of assessment and diagnostics as well as the knowledge required for planning and conducting diagnostic interventions.
- P4: Academic and Professional Skill Building (6 ECTS) is designed to narrow the gap between the knowledge students gain in the study programme and their further professional career. Additionally, academic skills will be further developed, including open science practices, academic writing and conference presentation skills.
- P5: Internship Module (12 ECTS) provides students with the opportunity to apply their theoretically obtained knowledge in practice during an internship of min. 350 hours.
- P6: Final Module (30 ECTS) supports students with completing an individual scientific project (writing a Master's thesis) and presenting and discussing it in a colloquium.

Students also have the opportunity to specialise in two out of the four elective compulsory project modules. Each of these modules involves literature review, planning, designing, and conducting an empirical research project, as well as analysing, describing, and discussing its results.

- WP5: Empirical Project Human Development (12 ECTS) deals with different psychological phenomena from the areas of cognition, emotion, learning, or development.
- WP6: Empirical Project in Cognition, Instruction, Learning, and Technology (12 ECTS) deals with questions related to the application of modern instructional methods and digital technologies to learning and teaching processes.
- WP7: Empirical Project in Motivation and Emotion (12 ECTS) deals with factors that predict performance in both school-based and out-of-school learning and teaching contexts.
- WP8: Empirical Project in Machine Learning, Artificial Intelligence, and Computational Modelling of Cognition (12 ECTS) deals with the application of AI methods in the field of the learning sciences.

In terms of elective compulsory modules, students can choose between:

- ECM1 Teaching Science Perspectives (6 ECTS): Provides students insights into Math, Biology, Physics, and Medical Education.
- ECM2 Educational Systems Perspectives (6 ECTS): Provides students insights into different educational systems globally and views on educational sociology.
- ECM3 Educational Counselling & Special Education Perspectives (6 ECTS): Provides students insights into counselling in early development, educational contexts and for students with special needs.

### Modulhandbuch

### Unterrichtssprache

Der Masterstudiengang findet ausschließlich in englischer Sprache statt.

### Prüfungs- und Studienordnungen

## Master’s Program in the Learning Sciences

Sprechstunden, Aushänge, Änderungen des Lehrangebots

## Fachstudienberatung Master’s Program in the Learning Sciences

Inhaltliche und spezifische Fragen des Studiums, Studienaufbau, Stundenplan, fachliche Schwerpunkte

## Prüfungsamt für Geistes- und Sozialwissenschaften

Prüfungsangelegenheiten, Prüfungsanmeldung, Semesteranrechnungsbescheide